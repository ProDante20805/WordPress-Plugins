<?php
/*
Plugin Name: CSV Content Display
Description: Displays the content of newly added CSV files in the wp-content/ill_prop_addresses directory in the browser console.
Version: 1.0
Author: Your Name
*/

// Define the directory to monitor
define('CSV_DISPLAY_DIR', WP_CONTENT_DIR . '/ill_prop_addresses');

// Hook to enqueue the script
add_action('wp_enqueue_scripts', 'csv_content_display_enqueue_scripts');

// Enqueue the JavaScript file
function csv_content_display_enqueue_scripts() {
    wp_enqueue_script('csv-content-display-script', plugin_dir_url(__FILE__) . 'csv-content-display.js', array('jquery'), '1.0', true);
    wp_localize_script('csv-content-display-script', 'csvDisplayAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('csv_display_nonce')
    ));
}

// Handle the AJAX request to get new CSV file content
add_action('wp_ajax_get_new_csv_content', 'csv_display_get_new_csv_content');
add_action('wp_ajax_nopriv_get_new_csv_content', 'csv_display_get_new_csv_content');

// Get and return new CSV file content
function csv_display_get_new_csv_content() {
    check_ajax_referer('csv_display_nonce', 'security');

    $known_files = get_option('csv_display_known_files', []);
    $current_files = array_diff(scandir(CSV_DISPLAY_DIR), array('..', '.'));
    $csv_files = array_filter($current_files, function($file) {
        return pathinfo($file, PATHINFO_EXTENSION) === 'csv';
    });

    $new_files = array_diff($csv_files, $known_files);

    if (!empty($new_files)) {
        $latest_file = end($new_files);
        $file_path = CSV_DISPLAY_DIR . '/' . $latest_file;

        // Read the file content
        $content = file_get_contents($file_path);

        // Parse the CSV content into an array
        $rows = array_map('str_getcsv', explode("\n", $content));

        // Optionally, clean up any empty rows
        $rows = array_filter($rows, function($row) {
            return !empty(array_filter($row));
        });

        update_option('csv_display_known_files', $csv_files);

        wp_send_json_success(array(
            'filename' => $latest_file,
            'content' => $rows // Send the CSV content as an array
        ));
    } else {
        wp_send_json_error('No new CSV files found.');
    }
}

// On activation, initialize the list of known files
register_activation_hook(__FILE__, 'csv_display_activate');
function csv_display_activate() {
    $initial_files = array_diff(scandir(CSV_DISPLAY_DIR), array('..', '.'));
    $csv_files = array_filter($initial_files, function($file) {
        return pathinfo($file, PATHINFO_EXTENSION) === 'csv';
    });
    update_option('csv_display_known_files', $csv_files);
}

// On deactivation, clean up
register_deactivation_hook(__FILE__, 'csv_display_deactivate');
function csv_display_deactivate() {
    delete_option('csv_display_known_files');
}
