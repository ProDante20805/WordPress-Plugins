function performSearch(item1, item2) {
    // Check if the DOM is ready
    document.addEventListener("DOMContentLoaded", function() {
        // Define the form data
        console.log(item1 + "and" + item2);
        const formData = new FormData();
        formData.append('inpNumber', item1); // The input field name might differ
        formData.append('inpStreet', item2); // The input field name might differ

        // Create and send an AJAX request
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'https://assessorpropertydetails.cookcountyil.gov/search/commonsearch.aspx?mode=address', true);
        
        // Set the expected response type (text or document for HTML)
        xhr.responseType = 'document';
        
        // Define what to do on response
        xhr.onload = function() {
            if (xhr.status === 200) {
                // Successfully received response
                console.log('Search Results:', xhr.response);
                // Process the HTML response here
                // You can access the response HTML using xhr.responseText or xhr.responseXML
                let parser = new DOMParser();
                let doc = parser.parseFromString(xhr.responseText, 'text/html');
                // Example: Find some element in the response
                let results = doc.querySelectorAll('.resultRow'); // Adjust the selector as needed
                results.forEach((result, index) => {
                    console.log(`Result ${index + 1}: ${result.innerText}`);
                });
            } else {
                console.error('Error during search:', xhr.statusText);
            }
        };

        // Send the request with the form data
        xhr.send(formData);
    });
}

function logCsvContent() {
    jQuery(document).ready(function($) {
        $.ajax({
            url: csvDisplayAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'get_new_csv_content',
                security: csvDisplayAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    console.log('New CSV File Detected: ' + response.data.filename);

                    // Check if content is an array and handle it
                    if (Array.isArray(response.data.content)) {
                        // response.data.content.forEach(function(row, index) {
                        //    // Check if the row has exactly 2 items
                        //     if (row.length === 2) {
                        //         // Access and log each item
                        //         performSearch(row[0], row[1]);
                        //     } else {
                        //         console.error('Row ' + index + ' does not have exactly 2 items:', row);
                        //     }
                        // });
                        // performSearch(response.data.content);
                        performSearch('17706', 'Clifton');
                    } else {
                        console.error('Expected content to be an array.');
                    }

                    clearInterval(intervalId);  // Clear the interval after displaying the content
                } else {
                    console.log('No new CSV files found.');
                }
            },
            error: function() {
                console.error('An error occurred while retrieving the new CSV file content.');
            }
        });
    });
}

var intervalId = setInterval(logCsvContent, 2000);
