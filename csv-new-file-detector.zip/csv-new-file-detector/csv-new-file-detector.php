<?php
/*
Plugin Name: CSV New File Detector
Description: Detects new CSV files in wp-content/ill_prop_addresses and logs them to the console.
Version: 1.0
Author: Your Name
*/

// Define the directory to monitor
define('CSV_MONITOR_DIR', WP_CONTENT_DIR . '/ill_prop_addresses');

// Hook to enqueue the script
add_action('wp_enqueue_scripts', 'csv_detector_enqueue_scripts');

// Enqueue the JavaScript file
function csv_detector_enqueue_scripts() {
    wp_enqueue_script('csv-detector-script', plugin_dir_url(__FILE__) . 'csv-detector.js', array('jquery'), '1.0', true);
    wp_localize_script('csv-detector-script', 'csvDetectorAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('csv_detector_nonce')
    ));
}

// Handle the AJAX request to get new CSV files
add_action('wp_ajax_get_new_csv_files', 'csv_detector_get_new_csv_files');
add_action('wp_ajax_nopriv_get_new_csv_files', 'csv_detector_get_new_csv_files');

// Get and return new CSV files
function csv_detector_get_new_csv_files() {
    check_ajax_referer('csv_detector_nonce', 'security');

    $known_files = get_option('csv_detector_known_files', []);
    $current_files = array_diff(scandir(CSV_MONITOR_DIR), array('..', '.'));
    $csv_files = array_filter($current_files, function($file) {
        return pathinfo($file, PATHINFO_EXTENSION) === 'csv';
    });

    $new_files = array_diff($csv_files, $known_files);

    if (!empty($new_files)) {
        update_option('csv_detector_known_files', $csv_files);
    }

    wp_send_json_success(array_values($new_files));
}

// On activation, initialize the list of known files
register_activation_hook(__FILE__, 'csv_detector_activate');
function csv_detector_activate() {
    $initial_files = array_diff(scandir(CSV_MONITOR_DIR), array('..', '.'));
    $csv_files = array_filter($initial_files, function($file) {
        return pathinfo($file, PATHINFO_EXTENSION) === 'csv';
    });
    update_option('csv_detector_known_files', $csv_files);
}

// On deactivation, clean up
register_deactivation_hook(__FILE__, 'csv_detector_deactivate');
function csv_detector_deactivate() {
    delete_option('csv_detector_known_files');
}
