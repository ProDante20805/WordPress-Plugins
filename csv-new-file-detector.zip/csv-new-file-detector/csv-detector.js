function logCsvFilenames() {
    jQuery(document).ready(function($) {
        $.ajax({
            url: csvDetectorAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'get_new_csv_files',
                security: csvDetectorAjax.nonce
            },
            success: function(response) {
                if(response.success && response.data.length > 0) {
                    console.log('New CSV Files: ' + response.data[0]);
                    clearInterval(intervalId);  // Clear the interval when new file is found
                } else {
                    console.log('No new CSV files found.');
                }
            },
            error: function() {
                console.error('An error occurred while retrieving the new CSV files.');
            }
        });
    });
}

var intervalId = setInterval(logCsvFilenames, 2000);

