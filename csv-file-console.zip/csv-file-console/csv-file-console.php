<?php
/*
Plugin Name: CSV File Console
Description: Displays the names of CSV files in the wp-content/ill_prop_addresses directory in the browser console.
Version: 1.0
Author: Your Name
*/

// Define the directory path
define('CSV_CONSOLE_DIR', WP_CONTENT_DIR . '/ill_prop_addresses');

// Hook to enqueue scripts
add_action('wp_enqueue_scripts', 'csv_console_enqueue_scripts');

// Function to enqueue necessary scripts
function csv_console_enqueue_scripts() {
    wp_enqueue_script('csv-console-script', plugin_dir_url(__FILE__) . 'csv-console.js', array('jquery'), '1.0', true);
    wp_localize_script('csv-console-script', 'csvConsoleAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('csv_console_nonce')
    ));
}

// Hook for handling the AJAX request
add_action('wp_ajax_get_csv_files', 'csv_console_get_csv_files');
add_action('wp_ajax_nopriv_get_csv_files', 'csv_console_get_csv_files');

// Function to handle the AJAX request and return CSV file names
function csv_console_get_csv_files() {
    check_ajax_referer('csv_console_nonce', 'security');
    $files = array_diff(scandir(CSV_CONSOLE_DIR), array('..', '.'));
    $csv_files = array_filter($files, function($file) {
        return pathinfo($file, PATHINFO_EXTENSION) === 'csv';
    });
    wp_send_json_success(array_values($csv_files));
}
