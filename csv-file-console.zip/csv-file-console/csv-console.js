jQuery(document).ready(function($) {
    $.ajax({
        url: csvConsoleAjax.ajax_url,
        type: 'POST',
        data: {
            action: 'get_csv_files',
            security: csvConsoleAjax.nonce
        },
        success: function(response) {
            if(response.success) {
                console.log('CSV Files:');
                response.data.forEach(function(file) {
                    console.log(file);
                });
            } else {
                console.error('Failed to retrieve CSV files.');
            }
        },
        error: function() {
            console.error('An error occurred while retrieving the CSV files.');
        }
    });
});
