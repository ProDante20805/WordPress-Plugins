jQuery(document).ready(function($) {
    function performScraping() {
        $.ajax({
            url: scraperData.ajax_url,
            type: 'POST',
            data: {
                action: 'web_scraping'
            },
            success: function(response) {
                if (response.success) {
                    console.log('Scraped HTML Content:', response.data.html);
                } else {
                    console.error('Scraping failed:', response.data.message);
                }
            },
            error: function() {
                console.error('An error occurred while performing the scraping.');
            }
        });
    }

    // Perform scraping when the DOM is ready or on some event
    performScraping();
});
