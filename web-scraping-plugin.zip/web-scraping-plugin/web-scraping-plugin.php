<?php
/**
 * Plugin Name: Click btn automatically
 * Description: A plugin to perform web scraping and display HTML content.
 * Version: 1.0
 * Author: dante
 */

// Enqueue JavaScript (if necessary)
function web_scraping_enqueue_scripts() {
    // Add any JavaScript enqueuing here if required
    wp_enqueue_script('scraper', plugins_url('/scraper.js', __FILE__), array('jquery'), null, true);
    wp_localize_script('scraper', 'scraperData', array(
        'ajax_url' => admin_url('admin-ajax.php'),
    ));
}
add_action('wp_enqueue_scripts', 'web_scraping_enqueue_scripts');

// AJAX handler for web scraping
function web_scraping_ajax_handler() {
    $response = perform_web_scraping();
    if ($response) {
        wp_send_json_success(array('html' => $response));
    } else {
        wp_send_json_error('Failed to scrape content.');
    }
}
add_action('wp_ajax_web_scraping', 'web_scraping_ajax_handler');
add_action('wp_ajax_nopriv_web_scraping', 'web_scraping_ajax_handler');

// Perform the web scraping
function perform_web_scraping() {
    $target_url = 'https://assessorpropertydetails.cookcountyil.gov/Search/Disclaimer.aspx?FromUrl=../search/commonsearch.aspx?mode=address';

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_URL, $target_url);

    // Execute the request to get the page content
    $initial_response = curl_exec($ch);
    if ($initial_response === false) {
        return false;
    }

    // Load the initial response to find the required form data and action URL
    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $dom->loadHTML($initial_response);
    $xpath = new DOMXPath($dom);

    // Example of finding the 'aaaa' button (assuming it's within a form)
    $form = $xpath->query('//form[@id="formId"]')->item(0); // Adjust the form ID accordingly
    $formAction = $form ? $form->getAttribute('action') : '';
    $formData = []; // You might need to construct this based on the form's input fields

    // Simulate button click by sending a form submission
    if ($formAction) {
        curl_setopt($ch, CURLOPT_URL, $formAction);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($formData));
        $response_after_click = curl_exec($ch);
    }

    // Close the cURL session
    curl_close($ch);

    return isset($response_after_click) ? $response_after_click : $initial_response;
}
