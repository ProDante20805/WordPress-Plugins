<?php
/*
Plugin Name: CSV Console Logger
Description: Logs the filename of a CSV file in the ill_prop_addresses directory to the console every 2 seconds.
Version: 1.0
Author: Your Name
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Enqueue the JavaScript file
function csv_console_logger_enqueue_scripts() {
    wp_enqueue_script( 'csv-console-logger-script', plugins_url( '/csv-console-logger.js', __FILE__ ), array(), '1.0', true );
    wp_localize_script( 'csv-console-logger-script', 'csvLogger', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
    ));
}
add_action( 'wp_enqueue_scripts', 'csv_console_logger_enqueue_scripts' );

// AJAX handler to get CSV filenames
function csv_console_logger_get_csv_filenames() {
    $directory = WP_CONTENT_DIR . '/ill_prop_addresses';
    $csv_files = glob( $directory . '/*.csv' );
    $file_names = array_map( 'basename', $csv_files );
    echo json_encode( $file_names );
    wp_die(); // This is required to terminate immediately and return a proper response
}
add_action( 'wp_ajax_get_csv_filenames', 'csv_console_logger_get_csv_filenames' );
add_action( 'wp_ajax_nopriv_get_csv_filenames', 'csv_console_logger_get_csv_filenames' );
