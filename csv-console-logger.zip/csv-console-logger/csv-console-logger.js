function logCsvFilenames() {
    fetch(csvLogger.ajax_url + '?action=get_csv_filenames')
        .then(response => response.json())
        .then(data => {
            console.log("CSV Files:", data);
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

setInterval(logCsvFilenames, 2000);
